<?php
/**
 * The footer template file
 *
 * @package ClearPath
 */
?>

<footer id="colophon" class="site-footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h4><?php bloginfo('name'); ?></h4>
                <p><?php bloginfo('description'); ?></p>
            </div>
            
            <div class="footer-section">
                <h4><?php _e('Quick Links', 'clearpath'); ?></h4>
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer',
                    'menu_id'        => 'footer-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                ));
                ?>
            </div>
            
            <div class="footer-section">
                <h4><?php _e('Contact', 'clearpath'); ?></h4>
                <p><?php _e('Email: info@example.com', 'clearpath'); ?></p>
                <p><?php _e('Phone: +1 (555) 123-4567', 'clearpath'); ?></p>
            </div>
            
            <div class="footer-section">
                <h4><?php _e('Follow Us', 'clearpath'); ?></h4>
                <div class="social-links">
                    <a href="#" aria-label="Facebook">Facebook</a>
                    <a href="#" aria-label="Twitter">Twitter</a>
                    <a href="#" aria-label="Instagram">Instagram</a>
                    <a href="#" aria-label="LinkedIn">LinkedIn</a>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.', 'clearpath'); ?></p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>

