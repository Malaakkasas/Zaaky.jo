# ClearPath WordPress Theme

A modern, interactive WordPress theme inspired by the ClearPath Framer template with a beautiful pastel navy blue, yellow, and white color scheme.

## Features

- **Modern Design**: Clean, contemporary design with smooth animations
- **Fully Responsive**: Perfectly optimized for all devices (desktop, tablet, mobile)
- **Interactive Elements**: Smooth scroll animations, hover effects, and transitions
- **Light Theme**: Bright, clean background with pastel color accents
- **Performance Optimized**: Fast loading times and optimized code
- **WordPress Ready**: Full WordPress integration with customizer support

## Color Scheme

- **Primary Color**: Pastel Navy Blue (#6B8EAF)
- **Secondary Color**: Pastel Yellow (#FFE66D)
- **Background**: White (#FFFFFF)
- **Accent Colors**: Light Navy, Light Yellow variations

## Installation

1. Download the `clearpath-theme.zip` file
2. Log in to your WordPress admin panel
3. Go to **Appearance > Themes**
4. Click **Add New**
5. Click **Upload Theme**
6. Choose the `clearpath-theme.zip` file
7. Click **Install Now**
8. Activate the theme

## Theme Setup

After activation:

1. Go to **Appearance > Menus** to set up your navigation menu
2. Go to **Appearance > Customize** to customize colors and other settings
3. Go to **Appearance > Widgets** to add widgets to the footer
4. Set a static homepage or use the front page template

## Customization

The theme includes a WordPress Customizer where you can:
- Change primary and secondary colors
- Upload a custom logo
- Customize menus and widgets

## Template Files

- `front-page.php` - Homepage template with hero, features, stats, and CTA sections
- `index.php` - Blog listing page
- `single.php` - Single post template
- `page.php` - Page template
- `header.php` - Site header with navigation
- `footer.php` - Site footer

## JavaScript Features

- Smooth scrolling
- Scroll reveal animations
- Counter animations for stats
- Mobile menu toggle
- Active menu highlighting
- Parallax effects

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## License

GPL v2 or later

## Support

For support and customization, please refer to the WordPress documentation or contact your developer.

## Credits

Inspired by ClearPath Framer Template
WordPress Theme Development

