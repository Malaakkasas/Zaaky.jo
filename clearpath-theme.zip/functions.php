<?php
/**
 * ClearPath Theme Functions
 *
 * @package ClearPath
 */

// Theme Setup
function clearpath_theme_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'clearpath'),
        'footer' => __('Footer Menu', 'clearpath'),
    ));
    
    // Add custom logo support
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
}
add_action('after_setup_theme', 'clearpath_theme_setup');

// Enqueue Styles and Scripts
function clearpath_enqueue_assets() {
    // Enqueue theme stylesheet
    wp_enqueue_style('clearpath-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue custom JavaScript
    wp_enqueue_script('clearpath-script', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true);
    
    // Add smooth scroll and animations
    wp_enqueue_script('clearpath-animations', get_template_directory_uri() . '/js/animations.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'clearpath_enqueue_assets');

// Register Widget Areas
function clearpath_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget Area', 'clearpath'),
        'id'            => 'footer-widget-area',
        'description'   => __('Widgets for the footer area', 'clearpath'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'clearpath_widgets_init');

// Custom Excerpt Length
function clearpath_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'clearpath_excerpt_length');

// Custom Excerpt More
function clearpath_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'clearpath_excerpt_more');

// Add body classes for styling
function clearpath_body_classes($classes) {
    if (is_front_page()) {
        $classes[] = 'front-page';
    }
    return $classes;
}
add_filter('body_class', 'clearpath_body_classes');

// Customizer Settings
function clearpath_customize_register($wp_customize) {
    // Add Color Section
    $wp_customize->add_section('clearpath_colors', array(
        'title'    => __('Theme Colors', 'clearpath'),
        'priority' => 30,
    ));
    
    // Primary Color
    $wp_customize->add_setting('primary_color', array(
        'default'           => '#6B8EAF',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', array(
        'label'    => __('Primary Color (Navy Blue)', 'clearpath'),
        'section'  => 'clearpath_colors',
        'settings' => 'primary_color',
    )));
    
    // Secondary Color
    $wp_customize->add_setting('secondary_color', array(
        'default'           => '#FFE66D',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_color', array(
        'label'    => __('Secondary Color (Yellow)', 'clearpath'),
        'section'  => 'clearpath_colors',
        'settings' => 'secondary_color',
    )));
}
add_action('customize_register', 'clearpath_customize_register');

