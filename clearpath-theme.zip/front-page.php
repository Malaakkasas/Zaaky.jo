<?php
/**
 * The front page template file
 *
 * @package ClearPath
 */

get_header();
?>

<main id="main" class="site-main">
    <!-- Hero Section -->
    <section class="hero-section" id="hero">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">Welcome to ClearPath</h1>
                <p class="hero-subtitle">Your journey to success starts here. We provide innovative solutions that help you achieve your goals with clarity and confidence.</p>
                <div class="hero-buttons">
                    <a href="#features" class="btn btn-primary">Get Started</a>
                    <a href="#about" class="btn btn-outline">Learn More</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section" id="features">
        <div class="container">
            <h2 class="section-title scroll-reveal">Why Choose Us</h2>
            <p class="section-subtitle scroll-reveal">Discover the features that make us stand out</p>
            
            <div class="features-grid">
                <div class="feature-card scroll-reveal">
                    <div class="feature-icon">🚀</div>
                    <h3 class="feature-title">Fast Performance</h3>
                    <p class="feature-description">Lightning-fast loading times and optimized performance ensure your users have the best experience.</p>
                </div>
                
                <div class="feature-card scroll-reveal">
                    <div class="feature-icon">🎨</div>
                    <h3 class="feature-title">Beautiful Design</h3>
                    <p class="feature-description">Modern, clean design with attention to detail that creates an engaging user experience.</p>
                </div>
                
                <div class="feature-card scroll-reveal">
                    <div class="feature-icon">📱</div>
                    <h3 class="feature-title">Fully Responsive</h3>
                    <p class="feature-description">Perfectly responsive across all devices - desktop, tablet, and mobile - for maximum reach.</p>
                </div>
                
                <div class="feature-card scroll-reveal">
                    <div class="feature-icon">⚡</div>
                    <h3 class="feature-title">Interactive Elements</h3>
                    <p class="feature-description">Smooth animations and transitions that bring your content to life and engage users.</p>
                </div>
                
                <div class="feature-card scroll-reveal">
                    <div class="feature-icon">🔒</div>
                    <h3 class="feature-title">Secure & Safe</h3>
                    <p class="feature-description">Built with security best practices to keep your data and users safe at all times.</p>
                </div>
                
                <div class="feature-card scroll-reveal">
                    <div class="feature-icon">💡</div>
                    <h3 class="feature-title">Easy to Customize</h3>
                    <p class="feature-description">Simple customization options that let you make it your own without any coding knowledge.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section" id="stats">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-item scroll-reveal">
                    <span class="stat-number" data-count="1000">0</span>
                    <span class="stat-label">Happy Clients</span>
                </div>
                <div class="stat-item scroll-reveal">
                    <span class="stat-number" data-count="500">0</span>
                    <span class="stat-label">Projects Completed</span>
                </div>
                <div class="stat-item scroll-reveal">
                    <span class="stat-number" data-count="50">0</span>
                    <span class="stat-label">Team Members</span>
                </div>
                <div class="stat-item scroll-reveal">
                    <span class="stat-number" data-count="99">0</span>
                    <span class="stat-label">Satisfaction Rate</span>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section" id="cta">
        <div class="container">
            <div class="cta-content scroll-reveal">
                <h2 class="cta-title">Ready to Get Started?</h2>
                <p>Join thousands of satisfied customers and take your business to the next level today.</p>
                <div class="cta-buttons">
                    <a href="#contact" class="btn btn-primary">Start Free Trial</a>
                    <a href="#features" class="btn btn-secondary">View Features</a>
                </div>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();

